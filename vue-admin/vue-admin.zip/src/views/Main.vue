<template>
	<section class="chart-container">
        <el-row>
            <el-col :span="12">
                <div id="todolist" style="width:100%; min-height:300px;">
                	<h3>待办事项</h3>
                </div>
            </el-col>
            <el-col :span="12">
                <div id="hotmsg" style="width:100%; min-height:300px;">
                	<h3>检测资讯速递</h3>
                </div>
            </el-col>
            <el-col :span="12">
                <div id="program" style="width:100%; min-height:300px;">
                	<h3>项目看板</h3>
                </div>
            </el-col>
            <el-col :span="12">
                <div id="static" style="width:100%; min-height:300px;">
                	<h3>统计看板</h3>
                </div>
            </el-col>
        </el-row>
    </section>
</template>

<script>
	export default {
	}

</script>

<style scoped>

</style>