import * as api from './api';

export default api;